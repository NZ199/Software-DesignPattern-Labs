package abstractfactory;
public class Client {

	public static void main(String[] args) {
		
		 PCFactory pcfactory  = new PCFactory("2 GB","500 GB","2.4 GHz");
		
	     Computer pccomputer = pcfactory.createComputer(); 
	     
	     System.out.print("\n PC Factory");
	     System.out.print("\n PC CPU is " + pccomputer.getCPU());
	     System.out.print("\n PC HDD is " + pccomputer.getHDD());
	     System.out.print("\n PC RAM is " +pccomputer.getRAM());
	     
	     ServerFactory serverfactory  = new ServerFactory("16 GB","1 TB","2.9 GHz");
	      
	     Computer servercomputer = serverfactory.createComputer(); 
	   
	     System.out.print("\n \n Server Factory");
	     System.out.print("\n Server CPU is " + servercomputer.getCPU());
	     System.out.print("\n Server HDD is " + servercomputer.getHDD());
	     System.out.print("\n Server RAM is " + servercomputer.getRAM());
	     
	     
	     
	     
	     

	}



}
