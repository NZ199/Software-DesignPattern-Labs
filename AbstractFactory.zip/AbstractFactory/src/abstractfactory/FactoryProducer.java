/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractfactory;

/**
 *
 * @author noufz
 */
public class FactoryProducer {
 
    public static superclassFActory  getFactory(String choice,String ram1,String hdd1,String cpu1){
        if(choice.equalsIgnoreCase("PC")){
            PCFactory pcFactory = new PCFactory(ram1,hdd1,cpu1);
            return pcFactory;
        }else if(choice.equalsIgnoreCase("SERVER")){  
            ServerFactory seFactory = new ServerFactory(ram1,hdd1,cpu1);
            return seFactory;
    }
        return null;
}
}
